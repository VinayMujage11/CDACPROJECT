package com.tollze.controllers;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tollze.entities.BookToll;
import com.tollze.entities.PaymentDetailsAsPerUser;
import com.tollze.repositories.PaymentDetailsRepository;
import com.tollze.repositories.TollBookRepository;


@RestController
public class ConfirmTollController {
	@Autowired
	public TollBookRepository tollBookrepository;
	@Autowired
	public PaymentDetailsRepository payrepo;
	@CrossOrigin(origins = "http://localhost:3000")
	@PutMapping("/updateToll/{id}")
	public String GetAmount(@PathVariable("id") String id , @RequestBody BookToll booktoll) 
	{
//		BookToll updateBookToll = tollBookrepository.updateBookToll(id, booktoll);
//		if(updateBookToll != null ) {
//			return "Toll Booked";
//		}
//		else {
//			return "Unable to Book Toll";
//		}
//		Date date = Date.valueOf(LocalDate.now());
//		booktoll.setDateOfbooking(date);
//		
//		LocalDate date2 =  (booktoll.getDateofjourney()).toLocalDate();
//		
//		
//		
//		booktoll.setDateOfExpiry(Date.valueOf(date2.plusDays(1)));
//		
//		tollBookrepository.findBytollBookId(id).setPaymentStatus("Paid");
//		tollBookrepository.findBytollBookId(id).setAmountToBePaid(booktoll.getAmountToBePaid());
//		tollBookrepository.findBytollBookId(id).setDateOfbooking(booktoll.getDateOfbooking());
//		tollBookrepository.findBytollBookId(id).setDateOfExpiry(booktoll.getDateOfExpiry());
		String confirmation="";
		
		if(tollBookrepository.findBytollBookId(id) != null) {
			PaymentDetailsAsPerUser p =payrepo.findByUserId(booktoll.getUserId());
			System.out.println(p);
			if((booktoll.getPaymentMode()).equals("Credit/DebitCard")) {
				
				if((p.getCredit_Card_Number()).isEmpty() & p.getCredit_Pin().isEmpty() & 
						(p.getDebit_Card_Number()).isEmpty() & p.getDebit_pin().isEmpty()) {
					confirmation = "No Credit/Debit card Available";
				}
				else {
					booktoll.setPaymentStatus("paid");
					Date date = Date.valueOf(LocalDate.now());
					booktoll.setDateOfbooking(date);
					LocalDate date2 =  (booktoll.getDateofjourney()).toLocalDate();
					
					booktoll.setDateOfExpiry(Date.valueOf(date2.plusDays(1)));
					tollBookrepository.save(booktoll);
					confirmation = "TollBooked";
				}
			}
			else if((booktoll.getPaymentMode()).equals("NetBanking")){
				if(((p.getAccountNumber()).isEmpty()) & ((p.getAccountHolderName()).isEmpty()) &
						((p.getBankName()).isEmpty()) & ((p.getBranchName()).isEmpty()) & ((p.getIfscCode()).isEmpty())) {
					confirmation = "Account Details Not Found";
					
				}
				else {
					booktoll.setPaymentStatus("paid");
					Date date = Date.valueOf(LocalDate.now());
					booktoll.setDateOfbooking(date);
					LocalDate date2 =  (booktoll.getDateofjourney()).toLocalDate();
					
					booktoll.setDateOfExpiry(Date.valueOf(date2.plusDays(1)));
					tollBookrepository.save(booktoll);
					confirmation = "TollBooked";
				}
				
			}
			else if((booktoll.getPaymentMode()).equals("DigitalWalletUPI")) {
				if((p.getUpiId()).isEmpty()) {
					confirmation = "No Upi Id Available";
					
				}
				else {
					booktoll.setPaymentStatus("paid");
					Date date = Date.valueOf(LocalDate.now());
					booktoll.setDateOfbooking(date);
					LocalDate date2 =  (booktoll.getDateofjourney()).toLocalDate();
					
					booktoll.setDateOfExpiry(Date.valueOf(date2.plusDays(1)));
					tollBookrepository.save(booktoll);
					confirmation = "TollBooked";
				}
				
			}
			else {
				if((p.getTollzeWallet()) <= 0 || p.getTollzeWallet() < booktoll.getAmountToBePaid()) {
					confirmation = "Insufficient Balance";
				}
				else {
					booktoll.setPaymentStatus("paid");
					Date date = Date.valueOf(LocalDate.now());
					booktoll.setDateOfbooking(date);
					LocalDate date2 =  (booktoll.getDateofjourney()).toLocalDate();
					
					booktoll.setDateOfExpiry(Date.valueOf(date2.plusDays(1)));
					tollBookrepository.save(booktoll);
					confirmation = "TollBooked";
				}
			}
			
		}
		
		
		return confirmation;
	}

}
