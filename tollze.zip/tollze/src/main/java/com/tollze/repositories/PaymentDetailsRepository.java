package com.tollze.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tollze.entities.PaymentDetailsAsPerUser;


public interface PaymentDetailsRepository extends JpaRepository<PaymentDetailsAsPerUser, String> {
	public PaymentDetailsAsPerUser findByUserId(String userId);
}
