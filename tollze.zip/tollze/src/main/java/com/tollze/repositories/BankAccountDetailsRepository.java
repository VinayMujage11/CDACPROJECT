package com.tollze.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tollze.entities.BankAccountDetails;



public interface BankAccountDetailsRepository extends JpaRepository<BankAccountDetails, Long>{

}
