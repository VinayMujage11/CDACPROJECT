package com.tollze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TollzeApplicationTests {

	@Test
	void contextLoads() {
	}

}
