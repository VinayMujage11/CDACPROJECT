package com.tollze.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Bank_Details")
public class BankAccountDetails {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	private String contact_Number;
    private String accountNumber;
    private String bankName;
    private String accountHolderName;
    private String ifscCode;
    private String branchName;
    private float balance;
    
    
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public BankAccountDetails(String accountNumber, String bankName, String accountHolderName, String ifscCode,
			String branchName, float balance ,String contact_Number) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.accountHolderName = accountHolderName;
		this.ifscCode = ifscCode;
		this.branchName = branchName;
		this.balance = balance;
		this.contact_Number = contact_Number;
	}

	public BankAccountDetails() {
		super();
	}

	public String getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		this.contact_Number = contact_Number;
	}
    
	

}
