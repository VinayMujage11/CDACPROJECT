package com.tollze.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Payment_details")
public class PaymentDetailsAsPerUser {
	
	
    @Id
    private String contact_Number;
    private String userId;
    private String accountNumber;
    private String bankName;
    private String accountHolderName;
    private String ifscCode;
    private String branchName;
    private String upiId;
    private String credit_Card_Number;
    private String credit_Pin;
    private String debit_Card_Number;
    private String debit_pin;
    private float tollzeWallet;

    

   

	public PaymentDetailsAsPerUser() {
		super();
	}

	public PaymentDetailsAsPerUser(String contact_Number, String userId, String accountNumber, String bankName,
			String accountHolderName, String ifscCode, String branchName, String upiId, String credit_Card_Number,
			String credit_Pin, String debit_Card_Number, String debit_pin, float tollzeWallet) {
		super();
		this.contact_Number = contact_Number;
		this.userId = userId;
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.accountHolderName = accountHolderName;
		this.ifscCode = ifscCode;
		this.branchName = branchName;
		this.upiId = upiId;
		this.credit_Card_Number = credit_Card_Number;
		this.credit_Pin = credit_Pin;
		this.debit_Card_Number = debit_Card_Number;
		this.debit_pin = debit_pin;
		this.tollzeWallet = tollzeWallet;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCredit_Card_Number() {
		return credit_Card_Number;
	}

	public void setCredit_Card_Number(String credit_Card_Number) {
		this.credit_Card_Number = credit_Card_Number;
	}

	public String getCredit_Pin() {
		return credit_Pin;
	}

	public void setCredit_Pin(String credit_Pin) {
		this.credit_Pin = credit_Pin;
	}

	public String getDebit_Card_Number() {
		return debit_Card_Number;
	}

	public void setDebit_Card_Number(String debit_Card_Number) {
		this.debit_Card_Number = debit_Card_Number;
	}

	public String getDebit_pin() {
		return debit_pin;
	}

	public void setDebit_pin(String debit_pin) {
		this.debit_pin = debit_pin;
	}

	public float getTollzeWallet() {
		return tollzeWallet;
	}

	public void setTollzeWallet(float tollzeWallet) {
		this.tollzeWallet = tollzeWallet;
	}

	public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }


	public String getUpiId() {
		return upiId;
	}

	public void setUpiId(String upiId) {
		this.upiId = upiId;
	}

	public String getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		this.contact_Number = contact_Number;
	}

	@Override
	public String toString() {
		return "PaymentDetailsAsPerUser [contact_Number=" + contact_Number + ", userId=" + userId + ", accountNumber="
				+ accountNumber + ", bankName=" + bankName + ", accountHolderName=" + accountHolderName + ", ifscCode="
				+ ifscCode + ", branchName=" + branchName + ", upiId=" + upiId + ", credit_Card_Number="
				+ credit_Card_Number + ", credit_Pin=" + credit_Pin + ", debit_Card_Number=" + debit_Card_Number
				+ ", debit_pin=" + debit_pin + ", tollzeWallet=" + tollzeWallet + "]";
	}

	
    
}
